function signal = find_movement(emg)
    s = sum(emg,1);
    

end