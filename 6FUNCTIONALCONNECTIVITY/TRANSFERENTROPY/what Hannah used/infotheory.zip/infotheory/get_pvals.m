function P = get_pvals(RtoC,null,allowed)

observed= RtoC(:,3);

P = observed * 0;

for i=1:length(null)
    
            include = allowed{i};
            nulldist = null{i};
            obsval = observed(i);

            x = sum(nulldist >= obsval);
            p = (1 + x) / (1 + length(nulldist));
            P(i) = p;
        
    
end

end